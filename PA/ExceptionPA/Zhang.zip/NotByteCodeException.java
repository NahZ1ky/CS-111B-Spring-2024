package ExceptionPA;

public class NotByteCodeException extends Exception{
    public NotByteCodeException(String message){
        super(message);
    }
}
