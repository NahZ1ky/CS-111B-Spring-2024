public interface Payable {
    public abstract double pay();
}
